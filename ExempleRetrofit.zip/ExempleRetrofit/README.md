# ExampleRetrofit
app with retrofit2
